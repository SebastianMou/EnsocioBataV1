from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('login/', views.user_login, name='user_login'),
    path('logout/', views.user_logout, name='user_logout'),
    path('register/', views.user_register, name='user_register'),
    path('profile/<str:username>/', views.profile, name='profile'),
    
    path('chat/<str:username>/', views.chat_user, name='chat_user'),
    path('chat/<str:recipient>/', views.chat, name='chat'),
    path('send/<str:recipient>/', views.send, name='send'),
    path('messages/<str:recipient>/', views.messages, name='messages'),

    path('user_post/', views.user_post, name='user_post'),
    path('detail_post/<int:pk>/', views.detail_post, name='detail_post'),
]