import pusher
from .models import Message
from django.contrib.auth.models import User
from django.db.models import Q

pusher_client = pusher.Pusher(
    app_id = "1579154",
    key = "9e61b3b60cfad3d41757",
    secret = "995dcdd651e85f00c93d",
    cluster = "us3",
    ssl=True
)

def send_message(sender, recipient, message):
    channel_name = f"private-chat-{sender}-{recipient}"
    pusher_client.trigger(channel_name, "new-message", {"message": message})
    # Create and save a Message object
    message_obj = Message.objects.create(sender=User.objects.get(username=sender),
                                          recipient=User.objects.get(username=recipient),
                                          content=message)
    print(message_obj.sender, '-' ,message_obj.content)

def get_messages(sender, recipient):
    messages = Message.objects.filter(
        Q(sender=sender, recipient=recipient) | Q(sender=recipient, recipient=sender)
    )
    messages = messages.order_by('timestamp')
    # print(messages)
    return messages



