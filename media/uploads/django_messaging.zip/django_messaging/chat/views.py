from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from .forms import RegisterForm, PostForm
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import UserProfile, Post, Message
from .chat import send_message
from .chat import send_message, get_messages
from django.http import JsonResponse
from django.db.models import Q

# Create your views here.
def home(request):
    posts = Post.objects.all()
    p_messages = Message.objects.all()
    context = {
        'posts': posts,
        'p_messages': p_messages,
    }
    return render(request, 'home.html', context)

def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            # Redirect to a success page.
            return redirect('/')
        else:
            return redirect('user_login')
    return render(request, 'auth/user_login.html')

def user_logout(request):
    logout(request)
    return redirect('user_login')

def user_register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data.get('email')
            username = form.cleaned_data.get('username')
            if User.objects.filter(email=email, username=username).exists():
                messages.error(request, 'Este correo electrónico ya está registrado.')
                return redirect('user_register')
            else:
                user = form.save(commit=False)
                user.save()
                return redirect('/')
    else:
        form = RegisterForm()
    context = {
        'form': form,
    }
    return render(request, 'auth/user_register.html', context)

@login_required
def profile(request, username):
    profile = get_object_or_404(User, username=username)
    posts = Post.objects.filter(author=profile)
    context = {'profile': profile, 'posts': posts}
    return render(request, 'auth/profile.html', context)

def dashboard(request):
    context = {}
    return render(request, 'dashboard.html', context) 

def user_post(request):
    if request.method == 'POST':
        form = PostForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            post.save()
            return redirect('detail_post', pk=post.pk)
    else:
        form = PostForm()
    context = {
        'form': form,
    }
    return render(request, 'service/user_post.html', context)


def detail_post(request, pk):
    post = get_object_or_404(Post, pk=pk)
    context = {
        'post': post,
    }
    return render(request, 'service/post_detail.html', context)

@login_required
def chat_user(request, username):
    recipient = get_object_or_404(User, username=username)
    p_messages = Message.objects.filter(
        Q(sender=request.user, recipient=recipient) | Q(sender=recipient, recipient=request.user)
    )
    if request.method == 'POST':
        message = request.POST.get('message')
        send_message(request.user.username, recipient.username, message)
    context = {
        'recipient': recipient,
        'p_messages': p_messages,
    }
    return render(request, 'chat.html', context)

@login_required
def chat(request, recipient):
    messages = get_messages(request.user.username, recipient)
    p_messages = Message.objects.filter(sender=request.user)
    p_messagess = Message.objects.filter(recipient=request.user)
    print("MESSAGE:", messages)
    context = {
        'recipient': recipient, 
        'messages': messages,
        'p_messages': p_messages,
        'p_messagess': p_messagess,
    }
    return render(request, 'chat.html', context)

def send(request, recipient):
    message = request.POST.get('message', '')
    send_message(request.user.username, recipient, message)
    return JsonResponse({'status': 'ok'})

def messages(request, recipient):
    messages = get_messages(request.user.username, recipient)
    return JsonResponse({'messages': messages})